# PROG POE Assignment Part 3
A budget management GUI application made using Windows Presentation Foundation (WPF)

## Requirements
.NetFramework v4.7.2

Windows environment

## Compiling
Load the project folder into an IDE and compile with "MainWindow.xaml.cs" as the main file.

## Changes made
Try-Catch structures implemented for exception handling when iterating data structures.
